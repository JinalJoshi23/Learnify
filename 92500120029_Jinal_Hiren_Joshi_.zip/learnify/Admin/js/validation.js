/* ============================================
   LEARNIFY — validation.js  (ADMIN side)
   Client-side JS validation for:
   - Admin login      (login.html)
   - Add Course form  (add-course.html)
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initAdminLoginForm();
  initAddCourseForm();
});

/* ---------- shared helpers ---------- */

function setFieldError(row, message) {
  row.classList.add('error');
  row.classList.remove('success');
  const errorEl = row.querySelector('.field-error');
  if (errorEl) errorEl.textContent = message;
}

function setFieldSuccess(row) {
  row.classList.remove('error');
  row.classList.add('success');
}

function getRow(input) {
  return input.closest('.form-row');
}

function isValidEmail(value) {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(value.trim());
}

function showFormAlert(alertEl, message, type) {
  if (!alertEl) return;
  alertEl.textContent = message;
  alertEl.className = `form-alert ${type}`;
}

/* ============================================
   ADMIN LOGIN (admin/login.html)
   Restricted to a single fixed administrator
   account — separate from the student login/
   signup system above.
   ============================================ */
const ADMIN_CREDENTIALS = {
  email: 'jinal.joshi@learnify.edu.in',
  password: 'learnify23',   // default — used until the admin changes it in Settings
};

/* If the admin changed their password in Settings, the new one is
   kept in localStorage and takes priority over the default above. */
const ADMIN_PASSWORD_KEY = 'learnify_admin_password';

const ADMIN_SESSION_KEY = 'learnify_admin_session';

function getAdminPassword() {
  try {
    return localStorage.getItem(ADMIN_PASSWORD_KEY) || ADMIN_CREDENTIALS.password;
  } catch (err) {
    return ADMIN_CREDENTIALS.password;
  }
}

function setAdminPassword(newPassword) {
  localStorage.setItem(ADMIN_PASSWORD_KEY, newPassword);
}

function initAdminLoginForm() {
  const form = document.querySelector('#adminLoginForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const emailInput = form.querySelector('#loginEmail');
    const row1 = getRow(emailInput);
    if (!isValidEmail(emailInput.value)) {
      setFieldError(row1, 'Enter a valid email address.');
      isValid = false;
    } else {
      setFieldSuccess(row1);
    }

    const passInput = form.querySelector('#loginPassword');
    const row2 = getRow(passInput);
    if (passInput.value.trim().length < 6) {
      setFieldError(row2, 'Password must be at least 6 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row2);
    }

    if (!isValid) {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
      return;
    }

    const emailMatches = emailInput.value.trim().toLowerCase() === ADMIN_CREDENTIALS.email.toLowerCase();
    const passwordMatches = passInput.value === getAdminPassword();

    if (!emailMatches || !passwordMatches) {
      showFormAlert(alertBox, 'Invalid admin credentials. Access is restricted to authorized staff.', 'error');
      return;
    }

    // Remember the admin is signed in (Settings page checks this)
    localStorage.setItem(ADMIN_SESSION_KEY, '1');

    showFormAlert(alertBox, 'Welcome, Jinal! Redirecting to your dashboard...', 'success');
    setTimeout(() => {
      window.location.href = 'dashboard.html';
    }, 900);
  });
}

/* ============================================
   BONUS: Admin "Add Course" form validation
   (admin/add-course.html)
   ============================================ */
function initAddCourseForm() {
  const form = document.querySelector('#addCourseForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const titleInput = form.querySelector('#courseTitle');
    const row1 = getRow(titleInput);
    if (titleInput.value.trim().length < 4) {
      setFieldError(row1, 'Course title must be at least 4 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row1);
    }

    const priceInput = form.querySelector('#coursePrice');
    const row2 = getRow(priceInput);
    if (!priceInput.value || Number(priceInput.value) <= 0) {
      setFieldError(row2, 'Enter a valid price greater than 0.');
      isValid = false;
    } else {
      setFieldSuccess(row2);
    }

    const categorySelect = form.querySelector('#courseCategory');
    const row3 = getRow(categorySelect);
    if (!categorySelect.value) {
      setFieldError(row3, 'Please select a category.');
      isValid = false;
    } else {
      setFieldSuccess(row3);
    }

    const descInput = form.querySelector('#courseDescription');
    const row4 = getRow(descInput);
    if (descInput.value.trim().length < 20) {
      setFieldError(row4, 'Description should be at least 20 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row4);
    }

    if (isValid) {
      showFormAlert(alertBox, 'Course saved successfully!', 'success');
      form.reset();
      form.querySelectorAll('.form-row').forEach(r => r.classList.remove('success', 'error'));
    } else {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
    }
  });
}
