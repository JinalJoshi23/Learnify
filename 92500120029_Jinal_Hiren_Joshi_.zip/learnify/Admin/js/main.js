/* ============================================
   LEARNIFY — main.js  (ADMIN side)
   Behaviour for the admin panel pages:
   - delete-row confirm on manage pages
   - Manage Students table (reads the real roster)
   - Dashboard recent enrollments + stat cards
   - admin profile pop-up and student photo modal
   - admin log out + active sidebar link
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initDeleteButtons();
  initManageStudentsPage();
  initDashboardRecentEnrollments();
  initProfileModal('adminProfileTrigger', 'adminProfileModal', 'closeAdminModal');
});

/* ============================================
   SHARED DATA STORE (browser-local, no backend)
   Two collections, both keyed by email:
   - learnify_students     → accounts created via Sign Up
   - learnify_enrollments  → course enrollments via Enroll form
   Defined here (not validation.js) because admin pages
   like manage-students.html and dashboard.html only load
   main.js, and still need to read this data.
   ============================================ */
const STUDENTS_KEY = 'learnify_students';

const ENROLLMENTS_KEY = 'learnify_enrollments';

function readCollection(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

function writeCollection(key, items) {
  localStorage.setItem(key, JSON.stringify(items));
}

function getStudentAccounts() { return readCollection(STUDENTS_KEY); }

function getEnrollments() { return readCollection(ENROLLMENTS_KEY); }

/* Merge accounts + enrollments into one roster, deduped by email.
   A student is "Confirmed" if they have an enrollment record,
   otherwise "Pending" (they have an account but haven't enrolled yet). */
function buildStudentRoster() {
  const accounts = getStudentAccounts();
  const enrollments = getEnrollments();
  const roster = new Map();

  accounts.forEach(acc => {
    roster.set(acc.email.toLowerCase(), {
      name: acc.name,
      email: acc.email,
      photoUrl: acc.photoUrl || '',
      course: null,
      joinedAt: acc.joinedAt || null,
      status: 'pending',
    });
  });

  enrollments.forEach(enr => {
    const key = enr.email.toLowerCase();
    const existing = roster.get(key);
    if (existing) {
      existing.course = enr.course;
      existing.status = 'published';
      if (!existing.joinedAt) existing.joinedAt = enr.joinedAt;
    } else {
      roster.set(key, {
        name: enr.name,
        email: enr.email,
        photoUrl: '',
        course: enr.course,
        joinedAt: enr.joinedAt,
        status: 'published',
      });
    }
  });

  return Array.from(roster.values()).sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt));
}

function formatDate(isoString) {
  if (!isoString) return '—';
  const d = new Date(isoString);
  if (isNaN(d)) return '—';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function initialsAvatar(name) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  return `<div style="width:44px;height:44px;border-radius:6px;background:var(--pen-pale);color:var(--pen-deep);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;flex-shrink:0;">${initials}</div>`;
}

/* Avatar for a student row: real photo if they added one at
   signup, initials fallback otherwise (including if the photo
   URL fails to load). Photo is clickable to zoom via the same
   profile modal pattern as the admin photo. */
function studentAvatar(student) {
  if (!student.photoUrl) return initialsAvatar(student.name);

  const initials = student.name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  return `<div style="position:relative; width:44px; height:44px; flex-shrink:0;">
    <img src="${student.photoUrl}" alt="${student.name}" class="profile-clickable student-avatar-thumb"
      data-name="${student.name}" data-photo="${student.photoUrl}" data-email="${student.email}"
      style="width:44px; height:44px; border-radius:6px; object-fit:cover;"
      onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
    <div style="display:none; width:44px; height:44px; border-radius:6px; background:var(--pen-pale); color:var(--pen-deep); align-items:center; justify-content:center; font-weight:700; font-size:0.85rem; position:absolute; top:0; left:0;">${initials}</div>
  </div>`;
}

/* Reusable click-to-zoom profile modal. Pass the id of the
   clickable trigger, the modal overlay, and its close button.
   Works for the admin profile now, and can be reused for
   student profile photos anywhere they're clickable. */
function initProfileModal(triggerId, modalId, closeId) {
  const trigger = document.querySelector(`#${triggerId}`);
  const modal = document.querySelector(`#${modalId}`);
  const closeBtn = document.querySelector(`#${closeId}`);
  if (!modal) return;

  function open() { modal.classList.add('open'); }
  function close() { modal.classList.remove('open'); }

  trigger?.addEventListener('click', open);
  closeBtn?.addEventListener('click', close);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) close();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });
}

/* Admin tables: confirm before removing a row (visual only — demo data) */
function initDeleteButtons() {
  const deleteButtons = document.querySelectorAll('.action-icons .delete');
  deleteButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr');
      if (!row) return;
      const nameCell = row.querySelector('strong')?.textContent || 'this item';
      const confirmed = window.confirm(`Remove ${nameCell}? This cannot be undone.`);
      if (confirmed) {
        row.style.opacity = '0';
        setTimeout(() => row.remove(), 200);
      }
    });
  });
}

/* ============================================
   ADMIN: Manage Students (admin/manage-students.html)
   Renders the real roster from localStorage — no
   seeded/demo names. Supports search, status filter,
   and delete (which removes from storage for real).
   ============================================ */
function initManageStudentsPage() {
  const tbody = document.querySelector('#studentsTableBody');
  if (!tbody) return;

  const countLabel = document.querySelector('#studentCountLabel');
  const noStudentsMsg = document.querySelector('#noStudents');
  const searchInput = document.querySelector('#studentSearch');
  const statusFilter = document.querySelector('#studentStatusFilter');
  const tableWrap = tbody.closest('.table-wrap');

  function statusBadge(status) {
    return status === 'published'
      ? '<span class="badge published">Confirmed</span>'
      : '<span class="badge pending">Pending</span>';
  }

  function render() {
    const roster = buildStudentRoster();
    const term = (searchInput?.value || '').trim().toLowerCase();
    const statusVal = statusFilter?.value || 'all';

    const filtered = roster.filter(s => {
      const matchesTerm = !term || s.name.toLowerCase().includes(term) || s.email.toLowerCase().includes(term);
      const matchesStatus = statusVal === 'all' || s.status === statusVal;
      return matchesTerm && matchesStatus;
    });

    if (countLabel) {
      countLabel.textContent = roster.length === 0
        ? 'No students yet'
        : `${roster.length} student${roster.length === 1 ? '' : 's'} enrolled`;
    }

    if (roster.length === 0) {
      if (tableWrap) tableWrap.style.display = 'none';
      if (noStudentsMsg) noStudentsMsg.style.display = 'block';
      tbody.innerHTML = '';
      return;
    }

    if (tableWrap) tableWrap.style.display = '';
    if (noStudentsMsg) noStudentsMsg.style.display = 'none';

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--ink-soft); padding:1.5rem;">No students match your search.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(s => `
      <tr data-email="${s.email}">
        <td><div class="row-course">${studentAvatar(s)}<div><strong>${s.name}</strong><span>${s.email}</span></div></div></td>
        <td>${s.course || '—'}</td>
        <td>${formatDate(s.joinedAt)}</td>
        <td>${statusBadge(s.status)}</td>
        <td><div class="action-icons"><button title="View">◎</button><button title="Delete" class="delete">✕</button></div></td>
      </tr>
    `).join('');
  }

  // Delete removes the student from both storage collections permanently
  tbody.addEventListener('click', (e) => {
    const avatarThumb = e.target.closest('.student-avatar-thumb');
    if (avatarThumb) {
      openStudentPhotoModal(avatarThumb.dataset);
      return;
    }

    const deleteBtn = e.target.closest('.delete');
    if (!deleteBtn) return;
    const row = deleteBtn.closest('tr');
    const email = row?.dataset.email;
    if (!email) return;

    const name = row.querySelector('strong')?.textContent || 'this student';
    if (!window.confirm(`Remove ${name}? This deletes their account and enrollment record.`)) return;

    writeCollection(STUDENTS_KEY, getStudentAccounts().filter(a => a.email.toLowerCase() !== email.toLowerCase()));
    writeCollection(ENROLLMENTS_KEY, getEnrollments().filter(en => en.email.toLowerCase() !== email.toLowerCase()));
    render();
  });

  searchInput?.addEventListener('input', render);
  statusFilter?.addEventListener('change', render);

  initProfileModal(null, 'studentProfileModal', 'closeStudentModal');

  render();
}

/* Fills and opens the student photo modal on manage-students.html.
   Reads the row's data-* attributes set by studentAvatar(). */
function openStudentPhotoModal(data) {
  const modal = document.querySelector('#studentProfileModal');
  if (!modal) return;

  const roster = buildStudentRoster();
  const student = roster.find(s => s.email.toLowerCase() === (data.email || '').toLowerCase());

  document.querySelector('#studentModalName').textContent = data.name || '';
  document.querySelector('#studentModalEmail').textContent = data.email || '';
  document.querySelector('#studentModalCourse').textContent = student?.course || 'Not enrolled yet';

  const photoSlot = document.querySelector('#studentModalPhotoSlot');
  if (photoSlot) {
    photoSlot.innerHTML = `<img src="${data.photo}" alt="${data.name}">`;
  }

  modal.classList.add('open');
}

/* ============================================
   ADMIN: Dashboard Recent Enrollments
   (admin/dashboard.html)
   Shows the most recent real signups/enrollments,
   and live-updates the Total Students / Pending
   Enrollments stat cards.
   ============================================ */
function initDashboardRecentEnrollments() {
  const tbody = document.querySelector('#recentEnrollmentsBody');
  if (!tbody) return;

  const noMsg = document.querySelector('#noRecentEnrollments');
  const tableWrap = tbody.closest('.table-wrap');
  const totalStudentsEl = document.querySelector('#statTotalStudents');
  const pendingStudentsEl = document.querySelector('#statPendingStudents');

  const roster = buildStudentRoster();

  if (totalStudentsEl) totalStudentsEl.textContent = roster.length;
  if (pendingStudentsEl) pendingStudentsEl.textContent = roster.filter(s => s.status === 'pending').length;

  if (roster.length === 0) {
    if (tableWrap) tableWrap.style.display = 'none';
    if (noMsg) noMsg.style.display = 'block';
    return;
  }

  if (tableWrap) tableWrap.style.display = '';
  if (noMsg) noMsg.style.display = 'none';

  const recent = roster.slice(0, 5);
  tbody.innerHTML = recent.map(s => `
    <tr>
      <td><div class="row-course">${studentAvatar(s)}<div><strong>${s.name}</strong><span>${s.email}</span></div></div></td>
      <td>${s.course || '—'}</td>
      <td>${formatDate(s.joinedAt)}</td>
      <td>${s.status === 'published' ? '<span class="badge published">Confirmed</span>' : '<span class="badge pending">Pending</span>'}</td>
    </tr>
  `).join('');

  tbody.addEventListener('click', (e) => {
    const avatarThumb = e.target.closest('.student-avatar-thumb');
    if (!avatarThumb) return;
    openStudentPhotoModal(avatarThumb.dataset);
  });

  initProfileModal(null, 'studentProfileModal', 'closeStudentModal');
}

/* Admin Log Out (sidebar footer) clears the admin session flag */
(function adminLogoutHandler() {
  document.querySelectorAll('.admin-sidebar .sidebar-footer a').forEach(link => {
    link.addEventListener('click', () => {
      try { localStorage.removeItem('learnify_admin_session'); } catch (err) {}
    });
  });
})();

/* Admin sidebar active-link highlighter based on current filename */
(function highlightActiveNav() {
  const page = window.location.pathname.split('/').pop() || 'dashboard.html';
  document.querySelectorAll('.admin-nav a').forEach(link => {
    const href = link.getAttribute('href');
    if (href === page) link.classList.add('active');
  });
})();
