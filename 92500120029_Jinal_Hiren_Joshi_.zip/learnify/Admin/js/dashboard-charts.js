/* ============================================
   LEARNIFY — dashboard-charts.js
   Tiny dependency-free SVG charts for admin/dashboard.html.
   Colours use CSS variables, so every theme works.
   (Chart numbers are sample data — swap the arrays below.)
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  const $ = (id) => document.getElementById(id);
  if (!$('growthChart')) return;

  // greeting + date
  const h = new Date().getHours();
  $('greeting').textContent = `Good ${h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening'}, Jinal 👋`;
  $('today').textContent = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const COLORS = ['var(--pen)', '#2E86DE', '#8E5BD9', '#1FA67A', '#F0A020'];

  /* ---- line / area chart: student growth ---- */
  function lineChart(el, labels, values) {
    const W = 600, H = 250, L = 30, R = 30, T = 30, B = 36;
    const max = Math.max(...values) * 1.15, min = 0;
    const x = (i) => L + (i * (W - L - R)) / (values.length - 1);
    const y = (v) => T + (1 - (v - min) / (max - min)) * (H - T - B);
    const pts = values.map((v, i) => `${x(i)},${y(v)}`).join(' ');
    el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%">
      <defs><linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" style="stop-color:var(--pen);stop-opacity:.28"/><stop offset="1" style="stop-color:var(--pen);stop-opacity:0"/>
      </linearGradient></defs>
      ${[0, 1, 2].map(i => `<line x1="${L}" x2="${W - R}" y1="${T + i * (H - T - B) / 2}" y2="${T + i * (H - T - B) / 2}" style="stroke:var(--rule)"/>`).join('')}
      <polygon points="${x(0)},${H - B} ${pts} ${x(values.length - 1)},${H - B}" fill="url(#gArea)"/>
      <polyline points="${pts}" fill="none" style="stroke:var(--pen)" stroke-width="3" stroke-linejoin="round"/>
      ${values.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="5" style="fill:var(--paper-card);stroke:var(--pen)" stroke-width="3"/>
        <text x="${x(i)}" y="${y(v) - 12}" text-anchor="middle" font-size="12" font-weight="700" style="fill:var(--ink)">${v}</text>
        <text x="${x(i)}" y="${H - 12}" text-anchor="middle" font-size="12" style="fill:var(--ink-soft)">${labels[i]}</text>`).join('')}
    </svg>`;
  }

  /* ---- donut chart with legend ---- */
  function donut(el, legendEl, data) {
    const total = data.reduce((s, d) => s + d.v, 0), C = 2 * Math.PI * 40;
    let offset = 0;
    const arcs = data.map((d, i) => {
      const len = (d.v / total) * C;
      const s = `<circle r="40" cx="60" cy="60" fill="none" stroke-width="18" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-offset}" style="stroke:${COLORS[i]}"/>`;
      offset += len; return s;
    }).join('');
    el.innerHTML = `<svg viewBox="0 0 120 120" width="190"><g transform="rotate(-90 60 60)">${arcs}</g>
      <text x="60" y="67" text-anchor="middle" font-size="22" font-weight="700" style="fill:var(--ink)">${total}</text></svg>`;
    legendEl.innerHTML = data.map((d, i) => `<li><i style="background:${COLORS[i]}"></i>${d.n}<b>${d.v}</b></li>`).join('');
  }

  /* ---- bar chart: revenue ---- */
  function barChart(el, labels, values) {
    const W = 600, H = 230, T = 26, B = 34, bw = 46, gap = (W - bw * values.length) / (values.length + 1);
    const max = Math.max(...values) * 1.1;
    el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%">${values.map((v, i) => {
      const bh = (v / max) * (H - T - B), bx = gap + i * (bw + gap);
      return `<rect x="${bx}" y="${H - B - bh}" width="${bw}" height="${bh}" rx="5" style="fill:${i === values.length - 1 ? 'var(--pen)' : 'var(--pen-pale)'}"/>
        <text x="${bx + bw / 2}" y="${H - B - bh - 8}" text-anchor="middle" font-size="12" font-weight="700" style="fill:var(--ink)">$${v}k</text>
        <text x="${bx + bw / 2}" y="${H - 12}" text-anchor="middle" font-size="12" style="fill:var(--ink-soft)">${labels[i]}</text>`;
    }).join('')}</svg>`;
  }

  const months = ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
  lineChart($('growthChart'), months, [60, 72, 85, 96, 108, 120]);
  donut($('donutChart'), $('donutLegend'), [
    { n: 'Development', v: 42 }, { n: 'Design', v: 28 }, { n: 'Marketing', v: 20 }, { n: 'Business', v: 22 }, { n: 'Data & AI', v: 16 }]);
  barChart($('revenueChart'), months, [9.2, 11.5, 12.8, 14.1, 16.4, 18.4]);
});
