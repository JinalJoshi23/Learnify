/* ============================================
   LEARNIFY — theme.js
   Loaded in <head> of EVERY page so the saved colour
   theme is applied before first paint (no flash).
   Choice is stored in localStorage under THEME_KEY.
   ============================================ */
(function () {
  var THEME_KEY = 'learnify_theme';

  var THEMES = [
    { id: 'notebook', name: 'Notebook', tag: 'Default · warm paper', colors: ['#F7F3EA', '#211D18', '#C1440E'] },
    { id: 'midnight', name: 'Midnight', tag: 'Dark mode',            colors: ['#16181F', '#ECE8DF', '#F0813F'] },
    { id: 'ocean',    name: 'Ocean',    tag: 'Cool blue',            colors: ['#F1F6FA', '#14212E', '#1F6FB5'] },
    { id: 'forest',   name: 'Forest',   tag: 'Calm green',           colors: ['#F2F6EF', '#1B2A1E', '#2F7D4F'] },
    { id: 'plum',     name: 'Plum',     tag: 'Soft purple',          colors: ['#F7F2F8', '#261A2B', '#8E3FA3'] }
  ];

  function isValid(id) {
    return THEMES.some(function (t) { return t.id === id; });
  }

  function getSaved() {
    try {
      var id = localStorage.getItem(THEME_KEY);
      return isValid(id) ? id : 'notebook';
    } catch (e) { return 'notebook'; }
  }

  function apply(id) {
    if (!isValid(id)) id = 'notebook';
    document.documentElement.setAttribute('data-theme', id);
  }

  function save(id) {
    if (!isValid(id)) return;
    apply(id);
    try { localStorage.setItem(THEME_KEY, id); } catch (e) {}
  }

  apply(getSaved());

  window.LearnifyTheme = { THEMES: THEMES, getSaved: getSaved, apply: apply, save: save };
})();
