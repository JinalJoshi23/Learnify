/* ============================================
   LEARNIFY — main.js  (CLIENT / student side)
   Behaviour for the student-facing pages:
   - mobile nav toggle
   - course filter/search (courses.html)
   - FAQ default open (contact.html)
   - logged-in navbar (Hi, name / Log Out / My Courses)
   - My Courses page
   - local data store used by sign up / login / enroll
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  initCourseFilter();
  initFaqDefaults();
  initSessionNav();
  initMyCoursesPage();
});

/* ============================================
   SHARED DATA STORE (browser-local, no backend)
   Two collections, both keyed by email:
   - learnify_students     → accounts created via Sign Up
   - learnify_enrollments  → course enrollments via Enroll form
   Defined here (not validation.js) because admin pages
   like manage-students.html and dashboard.html only load
   main.js, and still need to read this data.
   ============================================ */
const STUDENTS_KEY = 'learnify_students';

const ENROLLMENTS_KEY = 'learnify_enrollments';

function readCollection(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

function writeCollection(key, items) {
  localStorage.setItem(key, JSON.stringify(items));
}

function getStudentAccounts() { return readCollection(STUDENTS_KEY); }

function getEnrollments() { return readCollection(ENROLLMENTS_KEY); }

function saveStudentAccount(account) {
  const accounts = getStudentAccounts();
  accounts.push(account);
  writeCollection(STUDENTS_KEY, accounts);
}

function saveEnrollment(record) {
  const enrollments = getEnrollments();
  enrollments.push(record);
  writeCollection(ENROLLMENTS_KEY, enrollments);
}

/* Replace the stored password for one student account. Returns true if updated. */
function updateStudentPassword(email, newPassword) {
  const accounts = getStudentAccounts();
  const idx = accounts.findIndex(acc => acc.email.toLowerCase() === email.toLowerCase());
  if (idx === -1) return false;
  accounts[idx].password = newPassword;
  writeCollection(STUDENTS_KEY, accounts);
  return true;
}

function findStudentAccount(email) {
  return getStudentAccounts().find(acc => acc.email.toLowerCase() === email.toLowerCase());
}

function formatDate(isoString) {
  if (!isoString) return '—';
  const d = new Date(isoString);
  if (isNaN(d)) return '—';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function initialsAvatar(name) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  return `<div style="width:44px;height:44px;border-radius:6px;background:var(--pen-pale);color:var(--pen-deep);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;flex-shrink:0;">${initials}</div>`;
}

/* When a student is logged in (session set by validation.js on
   successful login), reveal the "My Courses" nav link and turn
   the Log In button into a "Hi, Name" greeting + Log Out control. */
function initSessionNav() {
  const loginBtn = document.querySelector('#navLoginBtn');
  const myCoursesItem = document.querySelector('#navMyCoursesItem');
  if (!loginBtn) return;

  let session = null;
  try {
    session = JSON.parse(localStorage.getItem('learnify_current_user'));
  } catch (err) {
    session = null;
  }

  if (session && session.name) {
    if (myCoursesItem) myCoursesItem.style.display = '';

    // Add a "Settings" link to the nav (theme + change password)
    const navList = document.querySelector('.nav-links');
    if (navList && !document.querySelector('#navSettingsItem')) {
      const li = document.createElement('li');
      li.id = 'navSettingsItem';
      const onSettings = window.location.pathname.split('/').pop() === 'settings.html';
      li.innerHTML = `<a href="settings.html"${onSettings ? ' class="active"' : ''}>Settings</a>`;
      navList.appendChild(li);
    }

    loginBtn.textContent = `Hi, ${session.name.split(' ')[0]}`;
    loginBtn.setAttribute('href', 'my-courses.html');

    // Insert a small Log Out link right after the greeting
    const logoutLink = document.createElement('a');
    logoutLink.href = '#';
    logoutLink.textContent = 'Log Out';
    logoutLink.className = 'btn btn-outline btn-sm';
    logoutLink.style.marginLeft = '0.5rem';
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('learnify_current_user');
      window.location.href = 'index.html';
    });
    loginBtn.insertAdjacentElement('afterend', logoutLink);
  }
}

/* ============================================
   CLIENT: My Courses (client/my-courses.html)
   Shows the logged-in student's own enrollments —
   matched by email against learnify_enrollments.
   ============================================ */
function initMyCoursesPage() {
  const listEl = document.querySelector('#myCoursesList');
  if (!listEl) return;

  const loggedOutState = document.querySelector('#loggedOutState');
  const emptyState = document.querySelector('#emptyState');
  const titleEl = document.querySelector('#myCoursesTitle');
  const subtitleEl = document.querySelector('#myCoursesSubtitle');

  let session = null;
  try {
    session = JSON.parse(localStorage.getItem('learnify_current_user'));
  } catch (err) {
    session = null;
  }

  if (!session || !session.email) {
    if (loggedOutState) loggedOutState.style.display = 'block';
    return;
  }

  if (titleEl) titleEl.textContent = `Welcome back, ${session.name.split(' ')[0]}`;

  const myEnrollments = getEnrollments()
    .filter(en => en.email.toLowerCase() === session.email.toLowerCase())
    .sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt));

  if (myEnrollments.length === 0) {
    if (subtitleEl) subtitleEl.textContent = "You haven't enrolled in any courses yet.";
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (subtitleEl) {
    subtitleEl.textContent = `You're enrolled in ${myEnrollments.length} course${myEnrollments.length === 1 ? '' : 's'}.`;
  }

  listEl.style.display = 'block';
  listEl.innerHTML = myEnrollments.map(en => `
    <div class="progress-card">
      ${initialsAvatar(en.course)}
      <div style="flex:1;">
        <strong style="font-family: var(--font-display); font-size: 1.05rem;">${en.course}</strong>
        <div style="font-size: 0.85rem; color: var(--ink-soft); margin-top: 2px;">Enrolled on ${formatDate(en.joinedAt)}</div>
      </div>
      <span class="badge published">Enrolled</span>
    </div>
  `).join('');
}

/* Mobile hamburger nav */
function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    links.classList.toggle('open');
  });
}

/* Course listing: search + category chip filter (courses.html) */
function initCourseFilter() {
  const searchInput = document.querySelector('#courseSearch');
  const chips = document.querySelectorAll('.chip[data-category]');
  const cards = document.querySelectorAll('.course-card[data-category]');
  const emptyState = document.querySelector('#noResults');

  if (!cards.length) return;

  let activeCategory = 'all';

  function applyFilter() {
    const term = (searchInput?.value || '').trim().toLowerCase();
    let visibleCount = 0;

    cards.forEach(card => {
      const title = card.querySelector('h3')?.textContent.toLowerCase() || '';
      const category = card.dataset.category;
      const matchesCategory = activeCategory === 'all' || category === activeCategory;
      const matchesSearch = title.includes(term);

      const show = matchesCategory && matchesSearch;
      card.style.display = show ? '' : 'none';
      if (show) visibleCount++;
    });

    if (emptyState) {
      emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', applyFilter);
  }

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeCategory = chip.dataset.category;
      applyFilter();
    });
  });
}

/* Keep first FAQ item open by default */
function initFaqDefaults() {
  const first = document.querySelector('.faq-item');
  if (first) first.setAttribute('open', '');
}

/* Navbar active-link highlighter based on current filename */
(function highlightActiveNav() {
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(link => {
    const href = link.getAttribute('href');
    if (href === page) link.classList.add('active');
  });
})();
