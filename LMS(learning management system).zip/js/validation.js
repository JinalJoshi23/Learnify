/* ============================================
   MINI LMS — validation.js
   Client-side JS validation for:
   FORM 1: Enrollment form  (client/enroll.html)
   FORM 2: Signup form      (client/login.html)
   Plus reused helpers for admin add-course form.
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initEnrollmentForm();
  initAuthForms();
  initAdminLoginForm();
  initAddCourseForm();
  initContactForm();
});

/* ---------- shared helpers ---------- */

function setFieldError(row, message) {
  row.classList.add('error');
  row.classList.remove('success');
  const errorEl = row.querySelector('.field-error');
  if (errorEl) errorEl.textContent = message;
}

function setFieldSuccess(row) {
  row.classList.remove('error');
  row.classList.add('success');
}

function getRow(input) {
  return input.closest('.form-row');
}

function isValidEmail(value) {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(value.trim());
}

function isValidPhone(value) {
  const digitsOnly = value.replace(/\D/g, '');
  return digitsOnly.length >= 10 && digitsOnly.length <= 13;
}

function showFormAlert(alertEl, message, type) {
  if (!alertEl) return;
  alertEl.textContent = message;
  alertEl.className = `form-alert ${type}`;
}

/* Note: shared data-store helpers (getStudentAccounts, saveEnrollment,
   findStudentAccount, etc.) live in main.js, which every page loads
   before this file — see main.js for the STUDENTS_KEY / ENROLLMENTS_KEY
   collections used throughout the forms below. */

/* ============================================
   FORM 1: ENROLLMENT FORM (client/enroll.html)
   Fields validated: full name, email, phone,
   course selection, terms checkbox
   ============================================ */
function initEnrollmentForm() {
  const form = document.querySelector('#enrollForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    // Full name
    const nameInput = form.querySelector('#fullName');
    if (nameInput) {
      const row = getRow(nameInput);
      if (nameInput.value.trim().length < 3) {
        setFieldError(row, 'Enter your full name (at least 3 characters).');
        isValid = false;
      } else {
        setFieldSuccess(row);
      }
    }

    // Email
    const emailInput = form.querySelector('#email');
    if (emailInput) {
      const row = getRow(emailInput);
      if (!isValidEmail(emailInput.value)) {
        setFieldError(row, 'Enter a valid email address, e.g. name@example.com');
        isValid = false;
      } else {
        setFieldSuccess(row);
      }
    }

    // Phone
    const phoneInput = form.querySelector('#phone');
    if (phoneInput) {
      const row = getRow(phoneInput);
      if (!isValidPhone(phoneInput.value)) {
        setFieldError(row, 'Enter a valid phone number (10 digits).');
        isValid = false;
      } else {
        setFieldSuccess(row);
      }
    }

    // Course selection
    const courseSelect = form.querySelector('#courseSelect');
    if (courseSelect) {
      const row = getRow(courseSelect);
      if (!courseSelect.value) {
        setFieldError(row, 'Please select a course to enroll in.');
        isValid = false;
      } else {
        setFieldSuccess(row);
      }
    }

    // Terms checkbox
    const termsCheckbox = form.querySelector('#agreeTerms');
    if (termsCheckbox) {
      const row = getRow(termsCheckbox);
      if (!termsCheckbox.checked) {
        setFieldError(row, 'You must agree to the terms to continue.');
        isValid = false;
      } else {
        row.classList.remove('error');
      }
    }

    if (isValid) {
      const courseText = courseSelect.options[courseSelect.selectedIndex].text.split(' — ')[0];
      saveEnrollment({
        name: nameInput.value.trim(),
        email: emailInput.value.trim(),
        phone: phoneInput.value.trim(),
        course: courseText,
        joinedAt: new Date().toISOString(),
      });

      showFormAlert(alertBox, 'Enrollment submitted! A confirmation has been sent to your email.', 'success');
      form.reset();
      form.querySelectorAll('.form-row').forEach(r => r.classList.remove('success', 'error'));
    } else {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
    }
  });
}

/* ============================================
   FORM 2: LOGIN / SIGNUP FORM (client/login.html)
   Validated: email, password rules, confirm
   password match (signup tab only)
   ============================================ */
function initAuthForms() {
  const loginForm = document.querySelector('#loginForm');
  const signupForm = document.querySelector('#signupForm');
  const loginTabBtn = document.querySelector('#tabLogin');
  const signupTabBtn = document.querySelector('#tabSignup');

  // Tab switching
  if (loginTabBtn && signupTabBtn && loginForm && signupForm) {
    loginTabBtn.addEventListener('click', () => {
      loginTabBtn.classList.add('active');
      signupTabBtn.classList.remove('active');
      loginForm.style.display = 'block';
      signupForm.style.display = 'none';
    });
    signupTabBtn.addEventListener('click', () => {
      signupTabBtn.classList.add('active');
      loginTabBtn.classList.remove('active');
      signupForm.style.display = 'block';
      loginForm.style.display = 'none';
    });
  }

  // Login — only succeeds for an email that was created via Sign Up
  if (loginForm) {
    const alertBox = loginForm.querySelector('.form-alert');
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      const emailInput = loginForm.querySelector('#loginEmail');
      const row1 = getRow(emailInput);
      if (!isValidEmail(emailInput.value)) {
        setFieldError(row1, 'Enter a valid email address.');
        isValid = false;
      } else {
        setFieldSuccess(row1);
      }

      const passInput = loginForm.querySelector('#loginPassword');
      const row2 = getRow(passInput);
      if (passInput.value.trim().length < 6) {
        setFieldError(row2, 'Password must be at least 6 characters.');
        isValid = false;
      } else {
        setFieldSuccess(row2);
      }

      if (!isValid) {
        showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
        return;
      }

      // Format is valid — now check against accounts actually signed up
      const account = findStudentAccount(emailInput.value.trim());

      if (!account) {
        setFieldError(row1, 'No account found for this email.');
        showFormAlert(alertBox, "We couldn't find an account with that email. Please sign up first.", 'error');
        return;
      }

      if (account.password !== passInput.value) {
        setFieldError(row2, 'Incorrect password.');
        showFormAlert(alertBox, 'Incorrect password for this account.', 'error');
        return;
      }

      // Success — real account, correct password
      localStorage.setItem('learnify_current_user', JSON.stringify({ name: account.name, email: account.email }));
      showFormAlert(alertBox, `Welcome back, ${account.name.split(' ')[0]}! Redirecting to My Courses...`, 'success');
      setTimeout(() => {
        window.location.href = 'my-courses.html';
      }, 1100);
    });
  }

  // Signup — creates the account that login will check against
  if (signupForm) {
    const alertBox = signupForm.querySelector('.form-alert');
    signupForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      const nameInput = signupForm.querySelector('#signupName');
      const row1 = getRow(nameInput);
      if (nameInput.value.trim().length < 3) {
        setFieldError(row1, 'Enter your full name.');
        isValid = false;
      } else {
        setFieldSuccess(row1);
      }

      const emailInput = signupForm.querySelector('#signupEmail');
      const row2 = getRow(emailInput);
      if (!isValidEmail(emailInput.value)) {
        setFieldError(row2, 'Enter a valid email address.');
        isValid = false;
      } else {
        setFieldSuccess(row2);
      }

      const passInput = signupForm.querySelector('#signupPassword');
      const row3 = getRow(passInput);
      const strongEnough = passInput.value.length >= 8;
      if (!strongEnough) {
        setFieldError(row3, 'Password must be at least 8 characters.');
        isValid = false;
      } else {
        setFieldSuccess(row3);
      }

      const confirmInput = signupForm.querySelector('#signupConfirm');
      const row4 = getRow(confirmInput);
      if (confirmInput.value !== passInput.value || confirmInput.value === '') {
        setFieldError(row4, 'Passwords do not match.');
        isValid = false;
      } else {
        setFieldSuccess(row4);
      }

      if (!isValid) {
        showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
        return;
      }

      // Prevent duplicate accounts for the same email
      if (findStudentAccount(emailInput.value.trim())) {
        setFieldError(row2, 'An account with this email already exists.');
        showFormAlert(alertBox, 'An account already exists for this email. Try logging in instead.', 'error');
        return;
      }

      // Save the new account — this is what login will check against
      saveStudentAccount({
        name: nameInput.value.trim(),
        email: emailInput.value.trim(),
        password: passInput.value,
        photoUrl: signupForm.querySelector('#signupPhoto')?.value.trim() || '',
        joinedAt: new Date().toISOString(),
      });

      showFormAlert(alertBox, 'Account created! Switching to Log In — use your new email and password.', 'success');
      signupForm.reset();
      signupForm.querySelectorAll('.form-row').forEach(r => r.classList.remove('success', 'error'));

      // Hand off to the login tab so the flow feels continuous
      setTimeout(() => {
        if (loginTabBtn) {
          loginTabBtn.click();
          const loginEmailInput = loginForm?.querySelector('#loginEmail');
          if (loginEmailInput) loginEmailInput.focus();
        }
      }, 1300);
    });
  }
}

/* ============================================
   ADMIN LOGIN (admin/login.html)
   Restricted to a single fixed administrator
   account — separate from the student login/
   signup system above.
   ============================================ */
const ADMIN_CREDENTIALS = {
  email: 'jinal.joshi@learnify.edu.in',
  password: 'learnify23',   // default — used until the admin changes it in Settings
};

/* If the admin changed their password in Settings, the new one is
   kept in localStorage and takes priority over the default above. */
const ADMIN_PASSWORD_KEY = 'learnify_admin_password';
const ADMIN_SESSION_KEY = 'learnify_admin_session';

function getAdminPassword() {
  try {
    return localStorage.getItem(ADMIN_PASSWORD_KEY) || ADMIN_CREDENTIALS.password;
  } catch (err) {
    return ADMIN_CREDENTIALS.password;
  }
}

function setAdminPassword(newPassword) {
  localStorage.setItem(ADMIN_PASSWORD_KEY, newPassword);
}

function initAdminLoginForm() {
  const form = document.querySelector('#adminLoginForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const emailInput = form.querySelector('#loginEmail');
    const row1 = getRow(emailInput);
    if (!isValidEmail(emailInput.value)) {
      setFieldError(row1, 'Enter a valid email address.');
      isValid = false;
    } else {
      setFieldSuccess(row1);
    }

    const passInput = form.querySelector('#loginPassword');
    const row2 = getRow(passInput);
    if (passInput.value.trim().length < 6) {
      setFieldError(row2, 'Password must be at least 6 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row2);
    }

    if (!isValid) {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
      return;
    }

    const emailMatches = emailInput.value.trim().toLowerCase() === ADMIN_CREDENTIALS.email.toLowerCase();
    const passwordMatches = passInput.value === getAdminPassword();

    if (!emailMatches || !passwordMatches) {
      showFormAlert(alertBox, 'Invalid admin credentials. Access is restricted to authorized staff.', 'error');
      return;
    }

    // Remember the admin is signed in (Settings page checks this)
    localStorage.setItem(ADMIN_SESSION_KEY, '1');

    showFormAlert(alertBox, 'Welcome, Jinal! Redirecting to your dashboard...', 'success');
    setTimeout(() => {
      window.location.href = 'dashboard.html';
    }, 900);
  });
}

/* ============================================
   BONUS: Admin "Add Course" form validation
   (admin/add-course.html)
   ============================================ */
function initAddCourseForm() {
  const form = document.querySelector('#addCourseForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const titleInput = form.querySelector('#courseTitle');
    const row1 = getRow(titleInput);
    if (titleInput.value.trim().length < 4) {
      setFieldError(row1, 'Course title must be at least 4 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row1);
    }

    const priceInput = form.querySelector('#coursePrice');
    const row2 = getRow(priceInput);
    if (!priceInput.value || Number(priceInput.value) <= 0) {
      setFieldError(row2, 'Enter a valid price greater than 0.');
      isValid = false;
    } else {
      setFieldSuccess(row2);
    }

    const categorySelect = form.querySelector('#courseCategory');
    const row3 = getRow(categorySelect);
    if (!categorySelect.value) {
      setFieldError(row3, 'Please select a category.');
      isValid = false;
    } else {
      setFieldSuccess(row3);
    }

    const descInput = form.querySelector('#courseDescription');
    const row4 = getRow(descInput);
    if (descInput.value.trim().length < 20) {
      setFieldError(row4, 'Description should be at least 20 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row4);
    }

    if (isValid) {
      showFormAlert(alertBox, 'Course saved successfully!', 'success');
      form.reset();
      form.querySelectorAll('.form-row').forEach(r => r.classList.remove('success', 'error'));
    } else {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
    }
  });
}

/* ============================================
   BONUS: Contact form validation (client/contact.html)
   ============================================ */
function initContactForm() {
  const form = document.querySelector('#contactForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const nameInput = form.querySelector('#contactName');
    const row1 = getRow(nameInput);
    if (nameInput.value.trim().length < 2) {
      setFieldError(row1, 'Enter your name.');
      isValid = false;
    } else {
      setFieldSuccess(row1);
    }

    const emailInput = form.querySelector('#contactEmail');
    const row2 = getRow(emailInput);
    if (!isValidEmail(emailInput.value)) {
      setFieldError(row2, 'Enter a valid email address.');
      isValid = false;
    } else {
      setFieldSuccess(row2);
    }

    const messageInput = form.querySelector('#contactMessage');
    const row3 = getRow(messageInput);
    if (messageInput.value.trim().length < 10) {
      setFieldError(row3, 'Message should be at least 10 characters.');
      isValid = false;
    } else {
      setFieldSuccess(row3);
    }

    if (isValid) {
      showFormAlert(alertBox, 'Message sent! We will get back to you within 24 hours.', 'success');
      form.reset();
      form.querySelectorAll('.form-row').forEach(r => r.classList.remove('success', 'error'));
    } else {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
    }
  });
}
