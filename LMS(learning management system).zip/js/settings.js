/* ============================================
   LEARNIFY — settings.js
   Powers admin/settings.html and client/settings.html
   - Colour theme picker (uses theme.js)
   - Change password form (admin or student)
   Needs main.js + validation.js loaded first.
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  const root = document.querySelector('#settingsRoot');
  if (!root) return;

  const role = root.dataset.role; // "admin" | "student"
  if (!requireSession(role)) return;

  initThemePicker();
  initPasswordToggles();
  initStrengthMeter();
  initChangePasswordForm(role);
});

/* ---------- who is signed in? ---------- */
function getStudentSession() {
  try { return JSON.parse(localStorage.getItem('learnify_current_user')); }
  catch (err) { return null; }
}

function requireSession(role) {
  const loggedIn = role === 'admin'
    ? localStorage.getItem('learnify_admin_session') === '1'
    : !!(getStudentSession() && getStudentSession().email);

  document.querySelector('#loggedOutState').style.display = loggedIn ? 'none' : 'block';
  document.querySelector('#settingsContent').style.display = loggedIn ? 'grid' : 'none';
  return loggedIn;
}

/* ---------- colour theme ---------- */
function initThemePicker() {
  const grid = document.querySelector('#themeGrid');
  const note = document.querySelector('#themeNote');
  if (!grid || !window.LearnifyTheme) return;

  const { THEMES, getSaved, save } = window.LearnifyTheme;

  function render() {
    const current = getSaved();
    grid.innerHTML = THEMES.map(t => `
      <button type="button" class="theme-option ${t.id === current ? 'active' : ''}" data-theme-id="${t.id}" aria-pressed="${t.id === current}">
        <div class="swatch">${t.colors.map(c => `<i style="background:${c}"></i>`).join('')}</div>
        <strong>${t.name}</strong>
        <span class="tag">${t.tag}</span>
      </button>
    `).join('');
  }

  grid.addEventListener('click', (e) => {
    const btn = e.target.closest('.theme-option');
    if (!btn) return;
    save(btn.dataset.themeId);
    render();
    const name = THEMES.find(t => t.id === btn.dataset.themeId).name;
    if (note) note.textContent = `${name} theme applied and saved.`;
  });

  render();
}

/* ---------- show / hide password ---------- */
function initPasswordToggles() {
  document.querySelectorAll('.pw-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input');
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
    });
  });
}

/* ---------- password strength meter ---------- */
function scorePassword(value) {
  let score = 0;
  if (value.length >= 8) score++;
  if (value.length >= 12) score++;
  if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
  if (/\d/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;
  return Math.min(score, 4);
}

function initStrengthMeter() {
  const input = document.querySelector('#newPassword');
  const bar = document.querySelector('#pwStrengthBar');
  const label = document.querySelector('#pwStrengthLabel');
  if (!input || !bar) return;

  const levels = [
    { text: 'Very weak', color: 'var(--error)' },
    { text: 'Weak', color: 'var(--error)' },
    { text: 'Okay', color: 'var(--pen)' },
    { text: 'Good', color: 'var(--success)' },
    { text: 'Strong', color: 'var(--success)' },
  ];

  input.addEventListener('input', () => {
    if (!input.value) {
      bar.style.width = '0';
      label.textContent = '';
      return;
    }
    const s = scorePassword(input.value);
    bar.style.width = `${(s + 1) * 20}%`;
    bar.style.background = levels[s].color;
    label.textContent = `Strength: ${levels[s].text}`;
  });
}

/* ---------- change password ---------- */
function initChangePasswordForm(role) {
  const form = document.querySelector('#changePasswordForm');
  if (!form) return;

  const alertBox = form.querySelector('.form-alert');
  const currentInput = form.querySelector('#currentPassword');
  const newInput = form.querySelector('#newPassword');
  const confirmInput = form.querySelector('#confirmPassword');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const rowCur = getRow(currentInput);
    const rowNew = getRow(newInput);
    const rowCon = getRow(confirmInput);

    // 1) current password: must be filled and must be correct
    let storedPassword = '';
    if (role === 'admin') {
      storedPassword = getAdminPassword();
    } else {
      const session = getStudentSession();
      const account = session && findStudentAccount(session.email);
      if (!account) {
        showFormAlert(alertBox, 'Your account could not be found. Please log in again.', 'error');
        return;
      }
      storedPassword = account.password;
    }

    if (!currentInput.value) {
      setFieldError(rowCur, 'Enter your current password.');
      isValid = false;
    } else if (currentInput.value !== storedPassword) {
      setFieldError(rowCur, 'Current password is incorrect.');
      isValid = false;
    } else {
      setFieldSuccess(rowCur);
    }

    // 2) new password: min length + must differ from current
    if (newInput.value.length < 8) {
      setFieldError(rowNew, 'New password must be at least 8 characters.');
      isValid = false;
    } else if (newInput.value === currentInput.value) {
      setFieldError(rowNew, 'New password must be different from the current one.');
      isValid = false;
    } else {
      setFieldSuccess(rowNew);
    }

    // 3) confirm match
    if (confirmInput.value === '' || confirmInput.value !== newInput.value) {
      setFieldError(rowCon, 'Passwords do not match.');
      isValid = false;
    } else {
      setFieldSuccess(rowCon);
    }

    if (!isValid) {
      showFormAlert(alertBox, 'Please fix the highlighted fields and try again.', 'error');
      return;
    }

    // save
    if (role === 'admin') {
      setAdminPassword(newInput.value);
    } else {
      updateStudentPassword(getStudentSession().email, newInput.value);
    }

    showFormAlert(alertBox, 'Password changed successfully. Use your new password next time you log in.', 'success');
    form.reset();
    form.querySelectorAll('.form-row').forEach(r => r.classList.remove('success', 'error'));
    form.querySelectorAll('.pw-toggle').forEach(b => { b.textContent = 'Show'; });
    form.querySelectorAll('input').forEach(i => { if (i.dataset.pw) i.type = 'password'; });
    document.querySelector('#pwStrengthBar').style.width = '0';
    document.querySelector('#pwStrengthLabel').textContent = '';
  });
}
