/* ============================================
   MINI LMS — main.js
   Shared UI behavior across client + admin pages:
   - mobile nav toggle
   - course filter/search (courses.html)
   - admin delete-row confirm (manage pages)
   - shared local data store (students/enrollments)
   - admin dynamic tables (manage-students, dashboard)
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  initCourseFilter();
  initDeleteButtons();
  initFaqDefaults();
  initSessionNav();
  initManageStudentsPage();
  initDashboardRecentEnrollments();
  initMyCoursesPage();
  initProfileModal('adminProfileTrigger', 'adminProfileModal', 'closeAdminModal');
});

/* ============================================
   SHARED DATA STORE (browser-local, no backend)
   Two collections, both keyed by email:
   - learnify_students     → accounts created via Sign Up
   - learnify_enrollments  → course enrollments via Enroll form
   Defined here (not validation.js) because admin pages
   like manage-students.html and dashboard.html only load
   main.js, and still need to read this data.
   ============================================ */
const STUDENTS_KEY = 'learnify_students';
const ENROLLMENTS_KEY = 'learnify_enrollments';

function readCollection(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

function writeCollection(key, items) {
  localStorage.setItem(key, JSON.stringify(items));
}

function getStudentAccounts() { return readCollection(STUDENTS_KEY); }
function getEnrollments() { return readCollection(ENROLLMENTS_KEY); }

function saveStudentAccount(account) {
  const accounts = getStudentAccounts();
  accounts.push(account);
  writeCollection(STUDENTS_KEY, accounts);
}

function saveEnrollment(record) {
  const enrollments = getEnrollments();
  enrollments.push(record);
  writeCollection(ENROLLMENTS_KEY, enrollments);
}

/* Replace the stored password for one student account. Returns true if updated. */
function updateStudentPassword(email, newPassword) {
  const accounts = getStudentAccounts();
  const idx = accounts.findIndex(acc => acc.email.toLowerCase() === email.toLowerCase());
  if (idx === -1) return false;
  accounts[idx].password = newPassword;
  writeCollection(STUDENTS_KEY, accounts);
  return true;
}

function findStudentAccount(email) {
  return getStudentAccounts().find(acc => acc.email.toLowerCase() === email.toLowerCase());
}

/* Merge accounts + enrollments into one roster, deduped by email.
   A student is "Confirmed" if they have an enrollment record,
   otherwise "Pending" (they have an account but haven't enrolled yet). */
function buildStudentRoster() {
  const accounts = getStudentAccounts();
  const enrollments = getEnrollments();
  const roster = new Map();

  accounts.forEach(acc => {
    roster.set(acc.email.toLowerCase(), {
      name: acc.name,
      email: acc.email,
      photoUrl: acc.photoUrl || '',
      course: null,
      joinedAt: acc.joinedAt || null,
      status: 'pending',
    });
  });

  enrollments.forEach(enr => {
    const key = enr.email.toLowerCase();
    const existing = roster.get(key);
    if (existing) {
      existing.course = enr.course;
      existing.status = 'published';
      if (!existing.joinedAt) existing.joinedAt = enr.joinedAt;
    } else {
      roster.set(key, {
        name: enr.name,
        email: enr.email,
        photoUrl: '',
        course: enr.course,
        joinedAt: enr.joinedAt,
        status: 'published',
      });
    }
  });

  return Array.from(roster.values()).sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt));
}

function formatDate(isoString) {
  if (!isoString) return '—';
  const d = new Date(isoString);
  if (isNaN(d)) return '—';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function initialsAvatar(name) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  return `<div style="width:44px;height:44px;border-radius:6px;background:var(--pen-pale);color:var(--pen-deep);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;flex-shrink:0;">${initials}</div>`;
}

/* Avatar for a student row: real photo if they added one at
   signup, initials fallback otherwise (including if the photo
   URL fails to load). Photo is clickable to zoom via the same
   profile modal pattern as the admin photo. */
function studentAvatar(student) {
  if (!student.photoUrl) return initialsAvatar(student.name);

  const initials = student.name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  return `<div style="position:relative; width:44px; height:44px; flex-shrink:0;">
    <img src="${student.photoUrl}" alt="${student.name}" class="profile-clickable student-avatar-thumb"
      data-name="${student.name}" data-photo="${student.photoUrl}" data-email="${student.email}"
      style="width:44px; height:44px; border-radius:6px; object-fit:cover;"
      onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
    <div style="display:none; width:44px; height:44px; border-radius:6px; background:var(--pen-pale); color:var(--pen-deep); align-items:center; justify-content:center; font-weight:700; font-size:0.85rem; position:absolute; top:0; left:0;">${initials}</div>
  </div>`;
}

/* When a student is logged in (session set by validation.js on
   successful login), reveal the "My Courses" nav link and turn
   the Log In button into a "Hi, Name" greeting + Log Out control. */
function initSessionNav() {
  const loginBtn = document.querySelector('#navLoginBtn');
  const myCoursesItem = document.querySelector('#navMyCoursesItem');
  if (!loginBtn) return;

  let session = null;
  try {
    session = JSON.parse(localStorage.getItem('learnify_current_user'));
  } catch (err) {
    session = null;
  }

  if (session && session.name) {
    if (myCoursesItem) myCoursesItem.style.display = '';

    // Add a "Settings" link to the nav (theme + change password)
    const navList = document.querySelector('.nav-links');
    if (navList && !document.querySelector('#navSettingsItem')) {
      const li = document.createElement('li');
      li.id = 'navSettingsItem';
      const onSettings = window.location.pathname.split('/').pop() === 'settings.html';
      li.innerHTML = `<a href="settings.html"${onSettings ? ' class="active"' : ''}>Settings</a>`;
      navList.appendChild(li);
    }

    loginBtn.textContent = `Hi, ${session.name.split(' ')[0]}`;
    loginBtn.setAttribute('href', 'my-courses.html');

    // Insert a small Log Out link right after the greeting
    const logoutLink = document.createElement('a');
    logoutLink.href = '#';
    logoutLink.textContent = 'Log Out';
    logoutLink.className = 'btn btn-outline btn-sm';
    logoutLink.style.marginLeft = '0.5rem';
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('learnify_current_user');
      window.location.href = 'index.html';
    });
    loginBtn.insertAdjacentElement('afterend', logoutLink);
  }
}

/* ============================================
   CLIENT: My Courses (client/my-courses.html)
   Shows the logged-in student's own enrollments —
   matched by email against learnify_enrollments.
   ============================================ */
function initMyCoursesPage() {
  const listEl = document.querySelector('#myCoursesList');
  if (!listEl) return;

  const loggedOutState = document.querySelector('#loggedOutState');
  const emptyState = document.querySelector('#emptyState');
  const titleEl = document.querySelector('#myCoursesTitle');
  const subtitleEl = document.querySelector('#myCoursesSubtitle');

  let session = null;
  try {
    session = JSON.parse(localStorage.getItem('learnify_current_user'));
  } catch (err) {
    session = null;
  }

  if (!session || !session.email) {
    if (loggedOutState) loggedOutState.style.display = 'block';
    return;
  }

  if (titleEl) titleEl.textContent = `Welcome back, ${session.name.split(' ')[0]}`;

  const myEnrollments = getEnrollments()
    .filter(en => en.email.toLowerCase() === session.email.toLowerCase())
    .sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt));

  if (myEnrollments.length === 0) {
    if (subtitleEl) subtitleEl.textContent = "You haven't enrolled in any courses yet.";
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (subtitleEl) {
    subtitleEl.textContent = `You're enrolled in ${myEnrollments.length} course${myEnrollments.length === 1 ? '' : 's'}.`;
  }

  listEl.style.display = 'block';
  listEl.innerHTML = myEnrollments.map(en => `
    <div class="progress-card">
      ${initialsAvatar(en.course)}
      <div style="flex:1;">
        <strong style="font-family: var(--font-display); font-size: 1.05rem;">${en.course}</strong>
        <div style="font-size: 0.85rem; color: var(--ink-soft); margin-top: 2px;">Enrolled on ${formatDate(en.joinedAt)}</div>
      </div>
      <span class="badge published">Enrolled</span>
    </div>
  `).join('');
}

/* Reusable click-to-zoom profile modal. Pass the id of the
   clickable trigger, the modal overlay, and its close button.
   Works for the admin profile now, and can be reused for
   student profile photos anywhere they're clickable. */
function initProfileModal(triggerId, modalId, closeId) {
  const trigger = document.querySelector(`#${triggerId}`);
  const modal = document.querySelector(`#${modalId}`);
  const closeBtn = document.querySelector(`#${closeId}`);
  if (!modal) return;

  function open() { modal.classList.add('open'); }
  function close() { modal.classList.remove('open'); }

  trigger?.addEventListener('click', open);
  closeBtn?.addEventListener('click', close);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) close();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });
}

/* Mobile hamburger nav */
function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    links.classList.toggle('open');
  });
}

/* Course listing: search + category chip filter (courses.html) */
function initCourseFilter() {
  const searchInput = document.querySelector('#courseSearch');
  const chips = document.querySelectorAll('.chip[data-category]');
  const cards = document.querySelectorAll('.course-card[data-category]');
  const emptyState = document.querySelector('#noResults');

  if (!cards.length) return;

  let activeCategory = 'all';

  function applyFilter() {
    const term = (searchInput?.value || '').trim().toLowerCase();
    let visibleCount = 0;

    cards.forEach(card => {
      const title = card.querySelector('h3')?.textContent.toLowerCase() || '';
      const category = card.dataset.category;
      const matchesCategory = activeCategory === 'all' || category === activeCategory;
      const matchesSearch = title.includes(term);

      const show = matchesCategory && matchesSearch;
      card.style.display = show ? '' : 'none';
      if (show) visibleCount++;
    });

    if (emptyState) {
      emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', applyFilter);
  }

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeCategory = chip.dataset.category;
      applyFilter();
    });
  });
}

/* Admin tables: confirm before removing a row (visual only — demo data) */
function initDeleteButtons() {
  const deleteButtons = document.querySelectorAll('.action-icons .delete');
  deleteButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr');
      if (!row) return;
      const nameCell = row.querySelector('strong')?.textContent || 'this item';
      const confirmed = window.confirm(`Remove ${nameCell}? This cannot be undone.`);
      if (confirmed) {
        row.style.opacity = '0';
        setTimeout(() => row.remove(), 200);
      }
    });
  });
}

/* Keep first FAQ item open by default */
function initFaqDefaults() {
  const first = document.querySelector('.faq-item');
  if (first) first.setAttribute('open', '');
}

/* ============================================
   ADMIN: Manage Students (admin/manage-students.html)
   Renders the real roster from localStorage — no
   seeded/demo names. Supports search, status filter,
   and delete (which removes from storage for real).
   ============================================ */
function initManageStudentsPage() {
  const tbody = document.querySelector('#studentsTableBody');
  if (!tbody) return;

  const countLabel = document.querySelector('#studentCountLabel');
  const noStudentsMsg = document.querySelector('#noStudents');
  const searchInput = document.querySelector('#studentSearch');
  const statusFilter = document.querySelector('#studentStatusFilter');
  const tableWrap = tbody.closest('.table-wrap');

  function statusBadge(status) {
    return status === 'published'
      ? '<span class="badge published">Confirmed</span>'
      : '<span class="badge pending">Pending</span>';
  }

  function render() {
    const roster = buildStudentRoster();
    const term = (searchInput?.value || '').trim().toLowerCase();
    const statusVal = statusFilter?.value || 'all';

    const filtered = roster.filter(s => {
      const matchesTerm = !term || s.name.toLowerCase().includes(term) || s.email.toLowerCase().includes(term);
      const matchesStatus = statusVal === 'all' || s.status === statusVal;
      return matchesTerm && matchesStatus;
    });

    if (countLabel) {
      countLabel.textContent = roster.length === 0
        ? 'No students yet'
        : `${roster.length} student${roster.length === 1 ? '' : 's'} enrolled`;
    }

    if (roster.length === 0) {
      if (tableWrap) tableWrap.style.display = 'none';
      if (noStudentsMsg) noStudentsMsg.style.display = 'block';
      tbody.innerHTML = '';
      return;
    }

    if (tableWrap) tableWrap.style.display = '';
    if (noStudentsMsg) noStudentsMsg.style.display = 'none';

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--ink-soft); padding:1.5rem;">No students match your search.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(s => `
      <tr data-email="${s.email}">
        <td><div class="row-course">${studentAvatar(s)}<div><strong>${s.name}</strong><span>${s.email}</span></div></div></td>
        <td>${s.course || '—'}</td>
        <td>${formatDate(s.joinedAt)}</td>
        <td>${statusBadge(s.status)}</td>
        <td><div class="action-icons"><button title="View">◎</button><button title="Delete" class="delete">✕</button></div></td>
      </tr>
    `).join('');
  }

  // Delete removes the student from both storage collections permanently
  tbody.addEventListener('click', (e) => {
    const avatarThumb = e.target.closest('.student-avatar-thumb');
    if (avatarThumb) {
      openStudentPhotoModal(avatarThumb.dataset);
      return;
    }

    const deleteBtn = e.target.closest('.delete');
    if (!deleteBtn) return;
    const row = deleteBtn.closest('tr');
    const email = row?.dataset.email;
    if (!email) return;

    const name = row.querySelector('strong')?.textContent || 'this student';
    if (!window.confirm(`Remove ${name}? This deletes their account and enrollment record.`)) return;

    writeCollection(STUDENTS_KEY, getStudentAccounts().filter(a => a.email.toLowerCase() !== email.toLowerCase()));
    writeCollection(ENROLLMENTS_KEY, getEnrollments().filter(en => en.email.toLowerCase() !== email.toLowerCase()));
    render();
  });

  searchInput?.addEventListener('input', render);
  statusFilter?.addEventListener('change', render);

  initProfileModal(null, 'studentProfileModal', 'closeStudentModal');

  render();
}

/* Fills and opens the student photo modal on manage-students.html.
   Reads the row's data-* attributes set by studentAvatar(). */
function openStudentPhotoModal(data) {
  const modal = document.querySelector('#studentProfileModal');
  if (!modal) return;

  const roster = buildStudentRoster();
  const student = roster.find(s => s.email.toLowerCase() === (data.email || '').toLowerCase());

  document.querySelector('#studentModalName').textContent = data.name || '';
  document.querySelector('#studentModalEmail').textContent = data.email || '';
  document.querySelector('#studentModalCourse').textContent = student?.course || 'Not enrolled yet';

  const photoSlot = document.querySelector('#studentModalPhotoSlot');
  if (photoSlot) {
    photoSlot.innerHTML = `<img src="${data.photo}" alt="${data.name}">`;
  }

  modal.classList.add('open');
}

/* ============================================
   ADMIN: Dashboard Recent Enrollments
   (admin/dashboard.html)
   Shows the most recent real signups/enrollments,
   and live-updates the Total Students / Pending
   Enrollments stat cards.
   ============================================ */
function initDashboardRecentEnrollments() {
  const tbody = document.querySelector('#recentEnrollmentsBody');
  if (!tbody) return;

  const noMsg = document.querySelector('#noRecentEnrollments');
  const tableWrap = tbody.closest('.table-wrap');
  const totalStudentsEl = document.querySelector('#statTotalStudents');
  const pendingStudentsEl = document.querySelector('#statPendingStudents');

  const roster = buildStudentRoster();

  if (totalStudentsEl) totalStudentsEl.textContent = roster.length;
  if (pendingStudentsEl) pendingStudentsEl.textContent = roster.filter(s => s.status === 'pending').length;

  if (roster.length === 0) {
    if (tableWrap) tableWrap.style.display = 'none';
    if (noMsg) noMsg.style.display = 'block';
    return;
  }

  if (tableWrap) tableWrap.style.display = '';
  if (noMsg) noMsg.style.display = 'none';

  const recent = roster.slice(0, 5);
  tbody.innerHTML = recent.map(s => `
    <tr>
      <td><div class="row-course">${studentAvatar(s)}<div><strong>${s.name}</strong><span>${s.email}</span></div></div></td>
      <td>${s.course || '—'}</td>
      <td>${formatDate(s.joinedAt)}</td>
      <td>${s.status === 'published' ? '<span class="badge published">Confirmed</span>' : '<span class="badge pending">Pending</span>'}</td>
    </tr>
  `).join('');

  tbody.addEventListener('click', (e) => {
    const avatarThumb = e.target.closest('.student-avatar-thumb');
    if (!avatarThumb) return;
    openStudentPhotoModal(avatarThumb.dataset);
  });

  initProfileModal(null, 'studentProfileModal', 'closeStudentModal');
}

/* Admin Log Out (sidebar footer) clears the admin session flag */
(function adminLogoutHandler() {
  document.querySelectorAll('.admin-sidebar .sidebar-footer a').forEach(link => {
    link.addEventListener('click', () => {
      try { localStorage.removeItem('learnify_admin_session'); } catch (err) {}
    });
  });
})();

/* Admin sidebar active-link highlighter based on current filename */
(function highlightActiveNav() {
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .admin-nav a').forEach(link => {
    const href = link.getAttribute('href');
    if (href === page) link.classList.add('active');
  });
})();
